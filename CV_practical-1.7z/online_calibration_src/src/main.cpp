
#include "CalibreHandler.h";

int main()
{
	CalibreHandler myCalibre;
	myCalibre.initialSetting();
}